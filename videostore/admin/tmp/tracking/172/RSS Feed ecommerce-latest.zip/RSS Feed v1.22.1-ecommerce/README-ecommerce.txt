osCommerce RSS Feed - eCommerce
by Vicente Aguilar <bisente@bisente.com>
http://www.bisente.com/proyectos/oscommerce-rss-feed-ecommerce/

based on RSS Feed
by Ralph2
http://forums.oscommerce.com/index.php?showuser=141735


WHAT?
=====

This plugin is a modificacion of Ralph2's RSS Feed for osCommerce that
adds Ecommerce tags to the feed. More info on the Ecommerce RSS module
here:

http://shopping.discovery.com/erss/


WHY?
====

The original RSS is great for "human" viewing, but lacks structured
information fields about the product's price, manufacturer, etc., useful for
automatic parsing and integration into other apps.


HOW?
====

Follow the instructions on the original "install.txt" file. To generate an
Ecommerce RSS feed, visit "rss.php?ecommerce=1".


CHANGES
=======

20070731

- fixed a SQL Injection bug. Thanks to Jim Nanney for the heads up.
  More info here:
  http://forums.oscommerce.com/index.php?showtopic=254845&st=80

20070506 (based on RSS Feed v1.22):

- moved from $HTTP_GET_VARS to $_GET (prefered).
- improved SQL: just one query.
- optional GET parameter "ecommerce=X" that enables e-commerce format.
